/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package assign_07_ques_06;

/**
 *
 * @author Quayle
 */
public class Assign_07_Ques_06 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        HelloViewer.main(args);
    }
    
}
